package com.clg.clgstudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClgstudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
