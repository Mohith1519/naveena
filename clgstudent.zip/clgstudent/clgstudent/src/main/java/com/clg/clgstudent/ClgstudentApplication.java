package com.clg.clgstudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClgstudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClgstudentApplication.class, args);
	}

}
