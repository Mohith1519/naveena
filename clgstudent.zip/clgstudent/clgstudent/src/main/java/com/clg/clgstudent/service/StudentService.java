package com.clg.clgstudent.service;

import java.util.List;

import com.clg.clgstudent.model.Student;

public interface StudentService {
	public void save(Student student);
	public List<Student> getAllStudents();
	public Student getAllById(int id);
	public List<Student> getAllStudentByCollege(String college);
	public List<Student> getAllStudentByBranch(String branch);
	public void deleteById(int id);

}
