package com.clg.clgstudent.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clg.clgstudent.model.Student;
import com.clg.clgstudent.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired 
	public StudentRepository studentRepository;
	@Override
	public void save(Student student) {
		// TODO Auto-generated method stub
		studentRepository.save(student);
		
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		List<Student> student =studentRepository.findAll();
		return student;
	}

	@Override
	public Student getAllById(int id) {
		// TODO Auto-generated method stub
		Optional<Student> student=studentRepository.findById(id);
		return student.get();
	}

	@Override
	public List<Student> getAllStudentByCollege(String college) {
		// TODO Auto-generated method stub
		List<Student> students=studentRepository.getAllByCollege(college);
		return students;
	}

	@Override
	public List<Student> getAllStudentByBranch(String branch) {
		// TODO Auto-generated method stub
		List<Student> students=studentRepository.getAllStudentsByBranch(branch);
		return students;
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		studentRepository.deleteById(id);
		
	}

}
