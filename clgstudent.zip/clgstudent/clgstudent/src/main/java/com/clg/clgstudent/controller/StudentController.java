package com.clg.clgstudent.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.clg.clgstudent.model.Student;
import com.clg.clgstudent.service.StudentServiceImpl;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	public StudentServiceImpl studentServiceImpl;
	@PostMapping("/save")
	public void save(@RequestBody Student student) {
		studentServiceImpl.save(student);
//		System.out.println(student);
	}
	@GetMapping("/getAllStudents")
	public List<Student> getAllStudents(){
		List<Student> students=studentServiceImpl.getAllStudents();
		return students;
	}
	@GetMapping("/getAllStudentsByBranch/{branch}")
	public List<Student> getAllStudentsByBranch(@PathVariable("branch") String branch){
		List<Student> students=studentServiceImpl.getAllStudentByBranch(branch);
		return students;
	}
	@GetMapping("/getAllStudentByCollege/{college}")
	public List<Student> getAllStudentByCollege(@PathVariable("college")String college){
		List<Student> students=studentServiceImpl.getAllStudentByCollege(college);
		return students;
	}
	@GetMapping("/getStudentById/{id}")
	public Student getStudentById(@PathVariable("id") int id) {
		return studentServiceImpl.getAllById(id);
	}
	@DeleteMapping("/deleteById/{id}")
	public void student(@PathVariable("id") int id) {
		studentServiceImpl.deleteById(id);
		
	}
	
}
